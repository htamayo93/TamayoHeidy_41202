/* 
 * File:   main.cpp
 * Author: Heidy Tamayo
 * Created on January 4, 2016, 10:18 AM
 * Purpose: check out IDE
 */

//System Libraries 
#include <iostream>
using namespace std;

//*User Libraries
 
//Global Constants

//Function prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare and initialize variables
    float         payRate=1e1f;//Pay Rate in $'s/hour
    unsigned char hrsWrkd=40;  //Hours worked (hrs)
       
    //Calculate or map inputs to outputs
    float payChck=payRate*hrsWrkd;//Pay check ($'s)
    
    //Output the results
    cout<<"pay Rate     =$ "<<payRate<<"'s/hr"<<endl;
    cout<<"Hours Worked =  "<<hrsWrkd<<" hrs"<<endl;
    cout<<"Hours Worked =  "<<static_cast<int>(hrsWrkd)<<"hrs"<<endl;
    cout<<"Pay Check    =$ "<<payChck<<endl;
    
    //Exit stage right
    return 0;
}
