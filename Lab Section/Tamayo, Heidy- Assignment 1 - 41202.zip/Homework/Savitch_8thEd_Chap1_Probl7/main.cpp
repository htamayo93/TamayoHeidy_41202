/* 
 * File:   main.cpp
 * Author: Heidy Tamayo
 * Created on January 10, 2016, 10:45 PM
 * Purpose:Writing a program that outputs "CS!" in large block letters in a border
 * of *'s and the message that computer science is cool.
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants

//Functional Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    
    //Output of the results
    cout<<"********************************************************************"<<endl;
    
    cout<<"       C C C               S S S S              ! !"<<endl;
    
    cout<<"    C        C            S         S           ! !"<<endl;
    
    cout<<"   C                     S                      ! !"<<endl;
    
    cout<<"  C                       S                     ! !"<<endl;
    
    cout<<" C                          S S S S             ! !"<<endl;
    
    cout<<"  C                                  S          ! !"<<endl;
    
    cout<<"   C                                  S         ! !"<<endl;
    
    cout<<"    C         C            S         S          ! !"<<endl;
    
    cout<<"       C C C                 S S S S            ! !"<<endl;
    
    cout<<"********************************************************************"<<endl;
    
    cout<<"    Computer Science is Cool Stuff!!!"<<endl;
    
    //Exit stage right
    return 0;
}

